# 插件入口文件，定义插件的版本和导出内容
__version__ = "0.1.0"
from .plugin import BiDirectionalLinksPlugin

__all__ = ["BiDirectionalLinksPlugin"]